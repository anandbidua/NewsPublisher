﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NewsPublisher.ExternalNewsSource;

namespace UnitTest
{
    [TestClass]
    public class GoogleNewsSourceTest
    {
        [TestMethod]
        public void TC1_GetNews_Datewise()
        {
            GoogleNewsSource GoogleNews = new GoogleNewsSource();
            var result = GoogleNews.GetNews(x => x.CreatedAt >= DateTime.UtcNow.AddDays(-1));
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TC2_Get_SportNews()
        {
            GoogleNewsSource GoogleNews = new GoogleNewsSource();
            var result = GoogleNews.GetNews(x => x.Category.Name == "Sports");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TC3_Get_PoliticalNews()
        {
            GoogleNewsSource GoogleNews = new GoogleNewsSource();
            var result = GoogleNews.GetNews(x => x.Category.Name == "Political");
            Assert.IsNotNull(result);
        }

    }
}
