﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NewsPublisher.InternalNewsSource;
using System;

namespace UnitTest
{
    [TestClass]
    public class InternalNewsSourceTest
    {
        [TestMethod]
        public void TC1_GetNews_Datewise()
        {
            InternalNewsSource GoogleNews = new InternalNewsSource();
            var result = GoogleNews.GetNews(x => x.CreatedAt >= DateTime.UtcNow.AddDays(-1));
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TC2_Get_SportNews()
        {
            InternalNewsSource GoogleNews = new InternalNewsSource();
            var result = GoogleNews.GetNews(x => x.Category.Name == "Sports");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TC3_Get_PoliticalNews()
        {
            InternalNewsSource GoogleNews = new InternalNewsSource();
            var result = GoogleNews.GetNews(x => x.Category.Name == "Political");
            Assert.IsNotNull(result);
        }
    }
}
