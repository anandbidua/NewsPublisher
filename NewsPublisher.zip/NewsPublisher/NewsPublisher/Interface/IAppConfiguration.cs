﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewsPublisher.Interface
{
    public interface IAppConfiguration
    {
        int MaxItemsOnPage { get; set; }
        int AdRatioOnPage { get; set; }
        int TotalItems { get; set; }
        int ItemsOnPage { get; set; }
        int ActualPage { get; set; }
        int TotalPages { get; set; }
        string Previous { get; set; }
        string Next { get; set; }
    }
}
