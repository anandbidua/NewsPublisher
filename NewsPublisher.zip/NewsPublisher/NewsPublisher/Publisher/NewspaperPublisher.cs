﻿using NewsPublisher.ExternalNewsSource;
using NewsPublisher.Interface;
using NewsPublisher.Modal;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace NewsPublisher.Publisher
{
    public class NewspaperPublisher : IPublisher
    {
        private readonly INewsSourceRegistry _newsSourceRegistery;
        private readonly IAppConfiguration _configuration;
        public NewspaperPublisher(INewsSourceRegistry newsSourceRegistery, IAppConfiguration configuration)
        {
            _newsSourceRegistery = newsSourceRegistery;
            _configuration = configuration;
        }
        public async Task<IEnumerable<News>> Publish(int pageNumber)
        {
            INewsSource source = new InternalNewsSource.InternalNewsSource();
            await _newsSourceRegistery.Register(source);

            source = new GoogleNewsSource();
            await _newsSourceRegistery.Register(source);

            source = new PressTrustOfIndiaNewsSource();
            await _newsSourceRegistery.Register(source);

            var list = await _newsSourceRegistery.GetAllRegisteredNews();

            var filteredList = list.Skip((pageNumber - 1) * _configuration.MaxItemsOnPage).Take(_configuration.MaxItemsOnPage);

            return filteredList;
        }
    }

}
