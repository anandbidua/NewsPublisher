﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewsPublisher.Modal
{
    public class NewsCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsAdvertisement { get; set; }
        public bool IsPolitical { get; set; }
        public bool IsTravel { get; set; }
        public bool IsSports { get; set; }
    }
}
