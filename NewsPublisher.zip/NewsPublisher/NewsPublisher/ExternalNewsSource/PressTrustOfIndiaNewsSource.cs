﻿using NewsPublisher.InternalNewsSource;
using NewsPublisher.Modal;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NewsPublisher.ExternalNewsSource
{
    public class PressTrustOfIndiaNewsSource : NewsSource
    {
        /// <summary>
        /// Get news from external source i.e PTI
        /// </summary>
        /// <param name="condition"></param>
        /// <returns></returns>
        public override Task<IEnumerable<News>> GetNews(Func<News, bool> condition)
        {
            throw new NotImplementedException();
        }
    }
}
