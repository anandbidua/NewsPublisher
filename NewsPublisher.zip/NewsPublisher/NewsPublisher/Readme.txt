﻿/*Following points have covered */.

1. Should be able to integrate news from internal and external registered source(External: Press Trust of India, Google news and Internal Sources).
2. Design registering to a news sources to get the news content.
3. Category component segregates the news on its type e.g. Political, Sports, Travel, Advertisements.
4. A maximum of 8 news/items can be accommodated on a page and it should be possible to extend the number of pages.
5.Applied SOLID Principles if required.
6.Used Dependency Injection.
7.Implimented task based async methods.

For Unit Test.

1.Used following packages NUnit and moq.